package com.gamelab.spacepro;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;

import java.io.BufferedReader;
import java.io.FileReader;

/** Cheap in-process readouts (no shell calls). */
final class Sys {

    static float tempC(Context c) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return b == null ? -1f : b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f;
    }

    static int battPct(Context c) {
        Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return b == null ? -1 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
    }

    static long ramFreeMb() {
        try (BufferedReader r = new BufferedReader(new FileReader("/proc/meminfo"))) {
            String l;
            while ((l = r.readLine()) != null) {
                if (l.startsWith("MemAvailable:")) {
                    String[] p = l.split("\\s+");
                    return Long.parseLong(p[1]) / 1024;
                }
            }
        } catch (Exception ignored) {}
        return -1;
    }
}
