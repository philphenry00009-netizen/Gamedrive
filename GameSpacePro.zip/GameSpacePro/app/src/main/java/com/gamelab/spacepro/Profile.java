package com.gamelab.spacepro;

/** One game in the library + its own tuning profile. */
final class Profile {
    String pkg;
    String label;
    int res = 1;                         // index into Engine.WIDTHS
    boolean dens = true;                 // scale density with resolution
    int flags = Engine.DEFAULT_FLAGS;    // Engine.F_* bitmask
    int bright = 0;                      // 0 = leave brightness alone, else 5..255
    int fsat = 100, fcon = 100, fbri = 100, fwarm = 0, flift = 0;   // screen filter

    boolean filterOn() { return fsat != 100 || fcon != 100 || fbri != 100 || fwarm != 0 || flift != 0; }
}
