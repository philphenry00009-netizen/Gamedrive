package com.gamelab.spacepro;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.PowerManager;
import android.os.Process;
import android.provider.Settings;

/** Builds a plain-text health report you can copy and send back. */
final class Diag {

    static String run(Context c, IShellService s) throws Exception {
        StringBuilder r = new StringBuilder();
        String me = c.getPackageName();
        int uid = ShizukuHelper.serverUid();
        boolean active = Store.sp(c).getBoolean("active", false);

        head(r, "DEVICE");
        kv(r, "Model", Build.MANUFACTURER + " " + Build.MODEL);
        kv(r, "Android", Build.VERSION.RELEASE + " (SDK " + Build.VERSION.SDK_INT + ")");
        kv(r, "Chipset", one(s, "getprop ro.board.platform") + " / " + one(s, "getprop ro.hardware"));
        kv(r, "Build", one(s, "getprop ro.build.display.id"));
        kv(r, "Screen", s.exec("wm size").trim().replace("\n", " | "));
        kv(r, "Density", s.exec("wm density").trim().replace("\n", " | "));

        head(r, "SHIZUKU & PERMISSIONS");
        res(r, "Shizuku running", ShizukuHelper.running(), "");
        res(r, "Shizuku mode", uid == 2000 || uid == 0, uid == 0 ? "root" : uid == 2000 ? "ADB shell" : "unknown (" + uid + ")");
        res(r, "Shizuku permission", ShizukuHelper.granted(), "");
        res(r, "Overlay (in-game dock)", Settings.canDrawOverlays(c), "");
        AppOpsManager ao = c.getSystemService(AppOpsManager.class);
        res(r, "Usage access (auto-reset)", ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(), me) == AppOpsManager.MODE_ALLOWED, "");
        res(r, "Notifications", c.getSystemService(NotificationManager.class).areNotificationsEnabled(), "");
        res(r, "Battery optimisation exempt", c.getSystemService(PowerManager.class).isIgnoringBatteryOptimizations(me),
                "set Game Space Pro to Unrestricted in Samsung battery settings if this is off");

        head(r, "COMMAND SUPPORT (as this phone answers)");
        String ap = s.exec("appops get " + me + " RUN_ANY_IN_BACKGROUND 2>&1 | head -n 1").trim();
        String apl = ap.toLowerCase();
        res(r, "appops (block app auto-restart)", !apl.contains("exception") && !apl.contains("unknown") && !apl.contains("error"),
                ap.isEmpty() ? "no output" : ap);
        res(r, "Do Not Disturb command", count(s, "cmd notification 2>&1 | grep -c set_dnd") > 0, "");
        String gm = s.exec("cmd game 2>&1 | head -n 12").toLowerCase();
        res(r, "Game Mode command", gm.contains("mode"), gm.contains("--mode") ? "Android 13+ syntax" : "Android 12 syntax");
        res(r, "Sustained performance command", count(s, "cmd power 2>&1 | grep -c fixed-performance") > 0, "");
        res(r, "Process list (ps)", count(s, "ps -A -o NAME | wc -l") > 20, count(s, "ps -A -o NAME | wc -l") + " processes");
        res(r, "Third-party app list", count(s, "pm list packages -3 | wc -l") > 0, count(s, "pm list packages -3 | wc -l") + " apps");
        if (active) {
            kv(r, "Screen filter", "skipped (a session is active)");
        } else {
            String out = s.exec(Filter.raw(100, 100, 100, 0, 0));
            s.exec(Filter.off());
            res(r, "Screen filter (SurfaceFlinger)", Filter.succeeded(out),
                    Filter.succeeded(out) ? "accepted" : "rejected: " + out.trim().replace("\n", " "));
        }

        head(r, "LIVE READINGS");
        kv(r, "Battery temp", String.format("%.1f C", Sys.tempC(c)));
        kv(r, "RAM available", Sys.ramFreeMb() + " MB");
        kv(r, "GPU clock", one(s, "cat /sys/class/kgsl/kgsl-3d0/gpuclk 2>&1"));
        kv(r, "Brightness", one(s, "settings get system screen_brightness") + " (auto mode "
                + one(s, "settings get system screen_brightness_mode") + ")");

        head(r, "SESSION STATE");
        kv(r, "Session flag", active ? "ACTIVE" : "normal");
        kv(r, "Service running", String.valueOf(GameService.running));
        kv(r, "Applied tweaks", Store.sp(c).getString("applied", "").isEmpty() ? "none" : Store.sp(c).getString("applied", ""));
        int restricted = 0;
        for (String l : Store.sp(c).getString("restricted", "").split("\n")) if (l.contains("=")) restricted++;
        kv(r, "Apps blocked from restarting", String.valueOf(restricted));
        kv(r, "Protected apps", String.valueOf(Store.getSet(c, "protect").size()));
        kv(r, "Always-close apps", String.valueOf(Store.getSet(c, "close").size()));
        return r.toString();
    }

    private static void head(StringBuilder r, String t) { r.append('\n').append(t).append('\n'); }
    private static void kv(StringBuilder r, String k, String v) { r.append("  ").append(k).append(": ").append(v).append('\n'); }
    private static void res(StringBuilder r, String k, boolean ok, String extra) {
        r.append(ok ? "  OK  " : "  !!  ").append(k);
        if (!extra.isEmpty()) r.append("  (").append(extra).append(')');
        r.append('\n');
    }
    private static String one(IShellService s, String cmd) throws Exception {
        String o = s.exec(cmd).trim();
        int nl = o.indexOf('\n');
        return nl > 0 ? o.substring(0, nl) : (o.isEmpty() ? "—" : o);
    }
    private static int count(IShellService s, String cmd) throws Exception {
        try { return Integer.parseInt(s.exec(cmd).trim()); } catch (NumberFormatException e) { return 0; }
    }
}
