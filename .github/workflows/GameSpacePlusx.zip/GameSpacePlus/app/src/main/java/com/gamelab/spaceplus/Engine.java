package com.gamelab.spaceplus;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.provider.Settings;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Snapshot -> apply -> restore.
 * The phone's ORIGINAL values are saved to disk before the first change, so restore()
 * puts back exactly what was there, even after a reboot or an app crash.
 */
final class Engine {

    static final int F_BLUR = 1, F_ANIM = 2, F_DND = 4, F_BATT = 8, F_GAME = 16, F_SUST = 32,
            F_SCREEN = 128, F_KILL = 256, F_KILLALL = 512, F_PERSIST = 1024;
    /** Conservative defaults: experimental switches (animations, Game Mode, sustained performance) are OFF. */
    static final int DEFAULT_FLAGS = F_BLUR | F_DND | F_BATT | F_SCREEN | F_KILL | F_KILLALL | F_PERSIST;

    /** Per-game downscale (Android 12 app-compat), applied to the game only. */
    static final String[] DOWN_NAMES = {"Native", "90%", "80%", "70%", "60%", "50%"};
    private static final String[] DOWN_CHANGE = {
            "", "DOWNSCALE_90", "DOWNSCALE_80", "DOWNSCALE_70", "DOWNSCALE_60", "DOWNSCALE_50"};
    private static final String ALL_DOWN = "DOWNSCALE_90 DOWNSCALE_80 DOWNSCALE_70 DOWNSCALE_60 DOWNSCALE_50";

    /** Whole-screen resolution (changes the phone's display size). */
    static final int[] WIDTHS = {0, 720, 540, 480, 360};
    static final String[] RES_NAMES = {"Native", "720p", "540p", "480p", "360p"};
    static final String SHIZUKU = "moe.shizuku.privileged.api";

    private static final Pattern PKG  = Pattern.compile("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+");
    private static final Pattern SIZE = Pattern.compile("(\\d+)x(\\d+)");
    private static final Pattern OPMODE = Pattern.compile("^(\\S+)\\s+RUN_ANY_IN_BACKGROUND:\\s*(\\w+)");

    private static final String SNAP =
            "echo \"OVSIZE=$(wm size | sed -n 's/^Override size: *//p')\";"
          + "echo \"PHSIZE=$(wm size | sed -n 's/^Physical size: *//p')\";"
          + "echo \"OVDEN=$(wm density | sed -n 's/^Override density: *//p')\";"
          + "echo \"PHDEN=$(wm density | sed -n 's/^Physical density: *//p')\";"
          + "echo \"blur=$(settings get global disable_window_blurs)\";"
          + "echo \"wanim=$(settings get global window_animation_scale)\";"
          + "echo \"tanim=$(settings get global transition_animation_scale)\";"
          + "echo \"danim=$(settings get global animator_duration_scale)\";"
          + "echo \"zen=$(settings get global zen_mode)\";"
          + "echo \"lowp=$(settings get global low_power)\";"
          + "echo \"adapt=$(settings get global adaptive_battery_management_enabled)\";"
          + "echo \"bmode=$(settings get system screen_brightness_mode)\";"
          + "echo \"bright=$(settings get system screen_brightness)\";"
          + "echo \"sto=$(settings get system screen_off_timeout)\"";

    // ------------------------------------------------------------ APPLY
    static String apply(Context c, IShellService s, Profile p) throws Exception {
        if (!PKG.matcher(p.pkg).matches()) throw new IllegalArgumentException("Invalid package name");
        SharedPreferences sp = Store.sp(c);

        // Never snapshot an already-boosted phone: put it back to normal first.
        if (sp.getBoolean("active", false)) restore(c, s);

        boolean whole = p.rmode == 1;
        Trace.add(c, "apply " + p.pkg + "  resolution=" + (whole ? "whole-screen " + RES_NAMES[p.wres] : "game-only " + DOWN_NAMES[p.res]));

        SharedPreferences.Editor e = sp.edit();
        for (String line : s.exec(SNAP).split("\n")) {
            int i = line.indexOf('=');
            if (i > 0) e.putString("snap." + line.substring(0, i).trim(), line.substring(i + 1).trim());
        }
        e.putBoolean("active", true).putString("applied", "").putString("game", p.pkg)
                .putString("restricted", "").putString("third", "").putString("compat", "")
                .putInt("curres", p.wres).commit();

        Set<String> applied = new LinkedHashSet<>();
        StringBuilder cmd = new StringBuilder();
        if (whole) resCmd(sp, WIDTHS[p.wres], p.dens, cmd, applied);

        int f = p.flags;
        if ((f & F_BLUR) != 0) { cmd.append("settings put global disable_window_blurs 1; "); applied.add("blur"); }
        if ((f & F_ANIM) != 0) {
            cmd.append("settings put global window_animation_scale 0; ")
               .append("settings put global transition_animation_scale 0; ")
               .append("settings put global animator_duration_scale 0; ");
            applied.add("anim");
        }
        if ((f & F_DND) != 0) { cmd.append("cmd notification set_dnd priority; "); applied.add("dnd"); }
        if ((f & F_BATT) != 0) {
            cmd.append("settings put global low_power 0; ")
               .append("settings put global adaptive_battery_management_enabled 0; ");
            applied.add("batt");
        }
        if ((f & F_SCREEN) != 0) { cmd.append("settings put system screen_off_timeout 1800000; "); applied.add("screen"); }
        if ((f & F_SUST) != 0) {
            cmd.append("cmd power set-fixed-performance-mode-enabled true 2>/dev/null; ");
            applied.add("sust");
        }
        if ((f & F_GAME) != 0) {
            cmd.append("cmd game mode performance ").append(p.pkg).append(" 2>/dev/null; ")
               .append("cmd game set --mode performance ").append(p.pkg).append(" 2>/dev/null; ");
            applied.add("game");
        }
        if (p.bright > 0) {
            cmd.append("settings put system screen_brightness_mode 0; ")
               .append("settings put system screen_brightness ").append(clamp(p.bright, 5, 255)).append("; ");
            applied.add("bright");
        }
        if (p.boostOn()) {
            cmd.append(Filter.on(p.fsat, p.fcon, p.fbri, p.fwarm, p.flift));
            applied.add("filter");
        }
        String compat = (!whole && p.res > 0) ? DOWN_CHANGE[p.res] : "";
        if (!compat.isEmpty()) applied.add("compat");

        sp.edit().putString("applied", join(applied)).putString("compat", compat).commit();   // BEFORE running
        s.exec(cmd.toString());
        if (applied.contains("size")) Thread.sleep(1500);   // let the display finish reconfiguring before the game starts

        String note = "";
        if (!compat.isEmpty()) {
            String out = s.exec(compatCmd(compat, p.pkg));
            boolean ok = out.contains("Enabled change");
            Trace.add(c, "game downscale " + compat + ": " + (ok ? "accepted" : "REJECTED -> " + out.trim().replace("\n", " ")));
            note = ok ? " Game downscale " + DOWN_NAMES[p.res] + " on."
                      : " This phone rejected game downscale (see Diagnostics).";
        }

        int closed = 0;
        if ((f & F_KILLALL) != 0) closed = closeApps(c, s, p.pkg, (f & F_PERSIST) != 0, true);
        else if ((f & F_KILL) != 0) s.exec("am kill-all");
        Trace.add(c, "closed " + closed + " apps");

        s.exec("monkey -p " + p.pkg + " -c android.intent.category.LAUNCHER 1 >/dev/null 2>&1");
        Trace.add(c, "launched " + p.pkg);
        return "Boosted." + note + (closed > 0 ? " " + closed + " apps closed." : "");
    }

    private static String compatCmd(String name, String pkg) {
        return "for n in " + ALL_DOWN + "; do if [ \"$n\" != " + name + " ]; then am compat reset $n " + pkg
                + " >/dev/null 2>&1 & fi; done; wait; am compat enable " + name + " " + pkg + " 2>&1";
    }

    // ------------------------------------------------- CLOSING APPS
    /**
     * Force-stops every running third-party app (plus the "always close" list) except protected ones.
     * With restrict=true each closed app is also blocked from restarting itself in the background
     * (appops RUN_ANY_IN_BACKGROUND=ignore); the original mode is saved so restore() puts it back.
     */
    static int closeApps(Context c, IShellService s, String game, boolean restrict, boolean initial) throws Exception {
        SharedPreferences sp = Store.sp(c);
        Set<String> keep = keepSet(c, game);

        if (initial) s.exec("am kill-all");

        Set<String> third = new HashSet<>();
        for (String x : sp.getString("third", "").split("\n")) if (!x.isEmpty()) third.add(x);
        if (initial || third.isEmpty()) {
            third = thirdParty(s);
            sp.edit().putString("third", String.join("\n", third)).commit();
        }

        Set<String> always = new LinkedHashSet<>();
        for (String a : Store.getSet(c, "close")) if (PKG.matcher(a).matches() && !keep.contains(a)) always.add(a);

        Set<String> running = runningNames(s);
        Set<String> kill = new LinkedHashSet<>();
        for (String n : running) {
            if ((third.contains(n) || always.contains(n)) && !keep.contains(n)) kill.add(n);
        }
        Set<String> block = new LinkedHashSet<>(kill);
        block.addAll(always);

        Map<String, String> restricted = loadRestricted(sp);
        Set<String> fresh = new LinkedHashSet<>();
        if (restrict) for (String b : block) if (!restricted.containsKey(b)) fresh.add(b);

        if (!fresh.isEmpty()) {
            String q = "for p in " + String.join(" ", fresh)
                    + "; do (echo \"$p $(appops get $p RUN_ANY_IN_BACKGROUND 2>/dev/null | head -n 1)\") & done; wait";
            Map<String, String> orig = new LinkedHashMap<>();
            for (String line : s.exec(q).split("\n")) {
                Matcher m = OPMODE.matcher(line.trim());
                if (m.find()) {
                    String mode = m.group(2).toLowerCase();
                    orig.put(m.group(1), (mode.equals("ignore") || mode.equals("deny")) ? mode : "default");
                }
            }
            for (String p : fresh) restricted.put(p, orig.containsKey(p) ? orig.get(p) : "default");
            saveRestricted(sp, restricted);   // BEFORE changing anything
        }

        Set<String> all = new LinkedHashSet<>(kill);
        all.addAll(fresh);
        if (all.isEmpty()) return 0;

        StringBuilder sb = new StringBuilder();
        for (String p : all) {
            sb.append('(');
            if (fresh.contains(p)) sb.append("appops set ").append(p).append(" RUN_ANY_IN_BACKGROUND ignore; ");
            sb.append(kill.contains(p) ? "am force-stop " + p : "true");
            sb.append(") & ");
        }
        sb.append("wait");
        s.exec(sb.toString());
        return kill.size();
    }

    private static Set<String> keepSet(Context c, String game) {
        Set<String> keep = new HashSet<>();
        keep.add(game);
        keep.add(c.getPackageName());
        keep.add(SHIZUKU);
        for (String x : Store.getSet(c, "protect")) if (PKG.matcher(x).matches()) keep.add(x);
        Intent home = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = c.getPackageManager().resolveActivity(home, 0);
        if (ri != null && ri.activityInfo != null) keep.add(ri.activityInfo.packageName);
        String ime = Settings.Secure.getString(c.getContentResolver(), "default_input_method");
        if (ime != null && ime.indexOf('/') > 0) keep.add(ime.substring(0, ime.indexOf('/')));
        return keep;
    }

    private static Set<String> thirdParty(IShellService s) throws Exception {
        Set<String> out = new HashSet<>();
        for (String l : s.exec("pm list packages -3").split("\n")) {
            l = l.trim();
            if (l.startsWith("package:")) {
                String pk = l.substring(8);
                if (PKG.matcher(pk).matches()) out.add(pk);
            }
        }
        return out;
    }

    private static Set<String> runningNames(IShellService s) throws Exception {
        Set<String> out = new HashSet<>();
        for (String l : s.exec("ps -A -o NAME").split("\n")) {
            String n = l.trim();
            int colon = n.indexOf(':');
            if (colon > 0) n = n.substring(0, colon);
            if (!n.isEmpty()) out.add(n);
        }
        return out;
    }

    private static Map<String, String> loadRestricted(SharedPreferences sp) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String l : sp.getString("restricted", "").split("\n")) {
            int i = l.indexOf('=');
            if (i > 0) m.put(l.substring(0, i), l.substring(i + 1));
        }
        return m;
    }

    private static void saveRestricted(SharedPreferences sp, Map<String, String> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, String> e : m.entrySet()) sb.append(e.getKey()).append('=').append(e.getValue()).append('\n');
        sp.edit().putString("restricted", sb.toString()).commit();
    }

    // ------------------------------------------------- LIVE CHANGES (whole-screen mode only)
    static void setWidth(Context c, IShellService s, int idx, boolean dens) throws Exception {
        SharedPreferences sp = Store.sp(c);
        Set<String> applied = appliedSet(sp);
        StringBuilder cmd = new StringBuilder();
        resCmd(sp, WIDTHS[idx], dens, cmd, applied);
        s.exec(cmd.toString());
        sp.edit().putString("applied", join(applied)).putInt("curres", idx).commit();
        Trace.add(c, "resolution -> " + RES_NAMES[idx]);
    }

    static void setDnd(Context c, IShellService s, boolean on) throws Exception {
        SharedPreferences sp = Store.sp(c);
        Set<String> applied = appliedSet(sp);
        applied.add("dnd");
        s.exec("cmd notification set_dnd " + (on ? "priority" : "off"));
        sp.edit().putString("applied", join(applied)).commit();
    }

    static void setBrightness(Context c, IShellService s, int value) throws Exception {
        SharedPreferences sp = Store.sp(c);
        Set<String> applied = appliedSet(sp);
        applied.add("bright");
        sp.edit().putString("applied", join(applied)).commit();
        s.exec("settings put system screen_brightness_mode 0; settings put system screen_brightness "
                + clamp(value, 5, 255));
    }

    // ---------------------------------------------------------- RESTORE
    static String restore(Context c, IShellService s) throws Exception {
        SharedPreferences sp = Store.sp(c);
        String ap = sp.getString("applied", "");
        StringBuilder cmd = new StringBuilder();
        Trace.add(c, "restore (applied: " + (ap.isEmpty() ? "none" : ap) + ")");

        if (ap.isEmpty()) {
            cmd.append("wm size reset; wm density reset; ");   // safe fallback
        } else {
            Set<String> a = new HashSet<>(Arrays.asList(ap.split(",")));
            if (a.contains("size")) cmd.append(wm("size", g(sp, "OVSIZE"), "\\d+x\\d+"));
            if (a.contains("den"))  cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
            if (a.contains("blur")) cmd.append(key("global", "disable_window_blurs", g(sp, "blur")));
            if (a.contains("anim")) {
                cmd.append(key("global", "window_animation_scale", g(sp, "wanim")))
                   .append(key("global", "transition_animation_scale", g(sp, "tanim")))
                   .append(key("global", "animator_duration_scale", g(sp, "danim")));
            }
            if (a.contains("dnd")) {
                int z = 0;
                try { z = Integer.parseInt(g(sp, "zen")); } catch (NumberFormatException ignored) {}
                String mode = z == 1 ? "priority" : z == 2 ? "none" : z == 3 ? "alarms" : "off";
                cmd.append("cmd notification set_dnd ").append(mode).append("; ");
            }
            if (a.contains("batt")) {
                cmd.append(key("global", "low_power", g(sp, "lowp")))
                   .append(key("global", "adaptive_battery_management_enabled", g(sp, "adapt")));
            }
            if (a.contains("bright")) {
                cmd.append(key("system", "screen_brightness", g(sp, "bright")))
                   .append(key("system", "screen_brightness_mode", g(sp, "bmode")));
            }
            if (a.contains("screen")) cmd.append(key("system", "screen_off_timeout", g(sp, "sto")));
            if (a.contains("sust"))   cmd.append("cmd power set-fixed-performance-mode-enabled false 2>/dev/null; ");
            if (a.contains("filter")) cmd.append(Filter.off());
            String game = sp.getString("game", "");
            if (PKG.matcher(game).matches()) {
                if (a.contains("game")) {
                    cmd.append("cmd game mode standard ").append(game).append(" 2>/dev/null; ")
                       .append("cmd game reset ").append(game).append(" 2>/dev/null; ");
                }
                if (a.contains("compat")) {
                    cmd.append("for n in ").append(ALL_DOWN).append("; do am compat reset $n ").append(game)
                       .append(" >/dev/null 2>&1 & done; wait; ");
                }
            }
        }
        s.exec(cmd.toString());

        Map<String, String> r = loadRestricted(sp);
        if (!r.isEmpty()) {
            StringBuilder sb = new StringBuilder();
            for (Map.Entry<String, String> en : r.entrySet()) {
                String mode = en.getValue();
                if (!PKG.matcher(en.getKey()).matches()) continue;
                if (!(mode.equals("ignore") || mode.equals("deny") || mode.equals("default"))) mode = "default";
                sb.append("(appops set ").append(en.getKey()).append(" RUN_ANY_IN_BACKGROUND ").append(mode).append(") & ");
            }
            sb.append("wait");
            s.exec(sb.toString());
        }

        sp.edit().putBoolean("active", false).putString("applied", "")
                .putString("restricted", "").putString("third", "").putString("compat", "").commit();
        Trace.add(c, "restore done");
        return "Everything restored to normal.";
    }

    // ---------------------------------------------------------- helpers
    private static void resCmd(SharedPreferences sp, int width, boolean dens,
                               StringBuilder cmd, Set<String> applied) {
        if (width <= 0) {   // back to native
            cmd.append(wm("size", g(sp, "OVSIZE"), "\\d+x\\d+"));
            cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
            return;
        }
        Matcher m = SIZE.matcher(g(sp, "PHSIZE"));
        if (!m.find()) return;
        int pw = Integer.parseInt(m.group(1)), ph = Integer.parseInt(m.group(2));
        if (pw <= width) return;
        int nh = Math.round(ph * (float) width / pw);
        nh -= nh % 2;
        cmd.append("wm size ").append(width).append('x').append(nh).append("; ");
        applied.add("size");
        if (dens) {
            try {
                int pd = Integer.parseInt(g(sp, "PHDEN"));
                int nd = Math.round(pd * (float) width / pw);
                if (nd > 0) { cmd.append("wm density ").append(nd).append("; "); applied.add("den"); }
            } catch (NumberFormatException ignored) {}
        } else {
            cmd.append(wm("density", g(sp, "OVDEN"), "\\d+"));
        }
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }

    private static String g(SharedPreferences sp, String k) { return sp.getString("snap." + k, ""); }

    private static Set<String> appliedSet(SharedPreferences sp) {
        Set<String> out = new LinkedHashSet<>();
        String a = sp.getString("applied", "");
        if (!a.isEmpty()) out.addAll(Arrays.asList(a.split(",")));
        return out;
    }

    private static String wm(String kind, String original, String regex) {
        return original.matches(regex) ? "wm " + kind + " " + original + "; " : "wm " + kind + " reset; ";
    }

    private static String key(String ns, String name, String v) {
        if (v.isEmpty() || v.equals("null") || !v.matches("[0-9A-Za-z._-]+"))
            return "settings delete " + ns + " " + name + "; ";
        return "settings put " + ns + " " + name + " " + v + "; ";
    }

    private static String join(Set<String> set) { return String.join(",", set); }
}
