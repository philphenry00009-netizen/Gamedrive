package com.gamelab.spaceplus;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * In-game "dock": a thin edge handle that expands into a control panel.
 * Only the handle's own few pixels (and the panel when open) intercept touches.
 */
final class Overlay {

    interface Actions {
        void res(int idx);
        void filter(int tintType);
        void bright(int delta);
        void clearRam();
        void dnd();
        void end();
    }

    private static final int RED = 0xFFFF2D4A, CARD = 0xFF22222A;
    private static final int[] DOCK_TINTS = {0, 1, 2, 5};     // Off, Dim, Warm, Brighten

    private final Context ctx;
    private final WindowManager wm;
    private final Actions act;
    private final boolean wholeScreen;
    private final WindowManager.LayoutParams hlp, plp;
    private View handle;
    private LinearLayout panel;
    private TextView stats;
    private Button bDnd;
    private final Button[] chips = new Button[Engine.WIDTHS.length];
    private final Button[] fchips = new Button[DOCK_TINTS.length];
    private boolean attached, expanded, failed;
    private int cur, curTint;
    private boolean dndOn;

    Overlay(Context c, Actions a, boolean dndInitially, int tintType, boolean wholeScreenMode) {
        ctx = c;
        act = a;
        dndOn = dndInitially;
        curTint = tintType;
        wholeScreen = wholeScreenMode;
        wm = c.getSystemService(WindowManager.class);

        hlp = params(dp(10), dp(56));
        hlp.gravity = Gravity.START | Gravity.TOP;
        hlp.x = 0;
        hlp.y = dp(220);

        plp = params(dp(280), WindowManager.LayoutParams.WRAP_CONTENT);
        plp.gravity = Gravity.START | Gravity.TOP;
        plp.x = dp(8);

        buildHandle();
        buildPanel();
    }

    private WindowManager.LayoutParams params(int w, int h) {
        return new WindowManager.LayoutParams(w, h,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
    }

    // ------------------------------------------------------------ public
    void show() {
        if (attached || failed) return;
        try {
            wm.addView(expanded ? panel : handle, expanded ? plp : hlp);
            attached = true;
        } catch (Exception e) {
            failed = true;
        }
    }

    void hide() {
        if (!attached) return;
        try { wm.removeView(expanded ? panel : handle); } catch (Exception ignored) {}
        attached = false;
    }

    void setCurrent(int idx) {
        cur = idx;
        for (int i = 0; i < chips.length; i++) if (chips[i] != null) style(chips[i], i == cur);
    }

    void setStats(String s) { if (expanded) stats.setText(s); }

    // ------------------------------------------------------------ build
    private void buildHandle() {
        handle = new View(ctx);
        handle.setBackground(round(0xCCFF2D4A, 5));
        handle.setOnTouchListener(new View.OnTouchListener() {
            int sy; float ty; boolean moved;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sy = hlp.y; ty = e.getRawY(); moved = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (Math.abs(e.getRawY() - ty) > dp(8)) moved = true;
                        if (moved) {
                            hlp.y = Math.max(0, sy + (int) (e.getRawY() - ty));
                            try { wm.updateViewLayout(handle, hlp); } catch (Exception ignored) {}
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) expand();
                        return true;
                }
                return false;
            }
        });
    }

    private void buildPanel() {
        panel = new LinearLayout(ctx);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(round(0xF2121216, 16));
        panel.setPadding(dp(14), dp(12), dp(14), dp(14));

        LinearLayout head = new LinearLayout(ctx);
        head.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label("GAME SPACE PLUS", 13, RED, true);
        title.setLetterSpacing(0.1f);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView x = label("✕", 16, Color.WHITE, true);
        x.setPadding(dp(10), 0, 0, 0);
        x.setOnClickListener(v -> collapse());
        head.addView(x);
        panel.addView(head);

        stats = label("", 12, 0xFFCCCCD6, false);
        stats.setTypeface(Typeface.MONOSPACE);
        panel.addView(stats, lp(dp(8)));

        if (wholeScreen) {
            panel.addView(label("RESOLUTION", 10, 0xFF8A8A96, true), lp(dp(10)));
            LinearLayout row = new LinearLayout(ctx);
            for (int i = 0; i < chips.length; i++) {
                final int idx = i;
                Button b = chip(Engine.RES_NAMES[i].replace("Native", "Nat"));
                b.setOnClickListener(v -> { setCurrent(idx); act.res(idx); });
                row.addView(b, weight());
                chips[i] = b;
                style(b, false);
            }
            panel.addView(row, lp(dp(4)));
        } else {
            panel.addView(label("Game downscale is set before launch.", 10, 0xFF8A8A96, false), lp(dp(8)));
        }

        panel.addView(label("SCREEN FILTER", 10, 0xFF8A8A96, true), lp(dp(10)));
        LinearLayout frow = new LinearLayout(ctx);
        String[] fnames = {"Off", "Dim", "Warm", "Bright"};
        for (int i = 0; i < DOCK_TINTS.length; i++) {
            final int type = DOCK_TINTS[i];
            final int slot = i;
            Button b = chip(fnames[i]);
            b.setOnClickListener(v -> {
                curTint = type;
                for (int k = 0; k < fchips.length; k++) style(fchips[k], k == slot);
                act.filter(type);
            });
            frow.addView(b, weight());
            fchips[i] = b;
            style(b, DOCK_TINTS[i] == curTint);
        }
        panel.addView(frow, lp(dp(4)));

        LinearLayout brow = new LinearLayout(ctx);
        Button dim = flat("☀  −");
        dim.setOnClickListener(v -> act.bright(-25));
        Button bri = flat("☀  +");
        bri.setOnClickListener(v -> act.bright(25));
        LinearLayout.LayoutParams lb = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lb.rightMargin = dp(6);
        brow.addView(dim, lb);
        brow.addView(bri, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(brow, lp(dp(8)));

        LinearLayout row2 = new LinearLayout(ctx);
        Button ram = flat("Close apps");
        ram.setOnClickListener(v -> act.clearRam());
        bDnd = flat(dndOn ? "DND: on" : "DND: off");
        bDnd.setOnClickListener(v -> { dndOn = !dndOn; bDnd.setText(dndOn ? "DND: on" : "DND: off"); act.dnd(); });
        LinearLayout.LayoutParams l1 = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        l1.rightMargin = dp(6);
        row2.addView(ram, l1);
        row2.addView(bDnd, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(row2, lp(dp(8)));

        Button end = flat("Reset & end session");
        end.setBackground(round(RED, 10));
        end.setOnClickListener(v -> act.end());
        panel.addView(end, lp(dp(10)));
    }

    private void expand() {
        try { wm.removeView(handle); } catch (Exception ignored) {}
        plp.y = hlp.y;
        try { wm.addView(panel, plp); } catch (Exception e) { failed = true; attached = false; return; }
        expanded = true;
        setCurrent(cur);
    }

    private void collapse() {
        try { wm.removeView(panel); } catch (Exception ignored) {}
        expanded = false;
        try { wm.addView(handle, hlp); } catch (Exception e) { failed = true; attached = false; }
    }

    // ------------------------------------------------------------ ui helpers
    private Button chip(String text) {
        Button b = new Button(ctx);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(0, dp(8), 0, dp(8));
        return b;
    }

    private LinearLayout.LayoutParams weight() {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        l.rightMargin = dp(3);
        return l;
    }

    private void style(Button b, boolean sel) {
        b.setBackground(round(sel ? RED : CARD, 8));
        b.setTextColor(Color.WHITE);
    }

    private Button flat(String t) {
        Button b = new Button(ctx);
        b.setText(t); b.setAllCaps(false); b.setTextSize(12); b.setTextColor(Color.WHITE);
        b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(dp(8), dp(10), dp(8), dp(10));
        b.setBackground(round(CARD, 10));
        return b;
    }

    private TextView label(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(ctx);
        t.setText(s); t.setTextSize(sp); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        l.topMargin = top;
        return l;
    }

    private GradientDrawable round(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private int dp(int v) { return Math.round(v * ctx.getResources().getDisplayMetrics().density); }
}
