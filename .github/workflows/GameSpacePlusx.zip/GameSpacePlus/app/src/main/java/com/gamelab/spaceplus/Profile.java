package com.gamelab.spaceplus;

/** One game in the library + its own tuning profile. */
final class Profile {
    String pkg;
    String label;

    int rmode = 0;          // 0 = per-game downscale (recommended), 1 = whole-screen resolution
    int res = 3;            // per-game downscale index  -> Engine.DOWN_NAMES
    int wres = 1;           // whole-screen index        -> Engine.WIDTHS
    boolean dens = true;    // whole-screen only: scale density with resolution

    int flags = Engine.DEFAULT_FLAGS;   // Engine.F_* bitmask
    int bright = 0;                     // 0 = leave brightness alone, else 5..255

    int ftype = 0;                      // overlay filter type  -> Tint.NAMES (0 = off)
    int fstr = 25;                      // overlay filter strength, percent
    int fsat = 100, fcon = 100, fbri = 100, fwarm = 0, flift = 0;   // colour boost (SurfaceFlinger)

    boolean boostOn() { return !Filter.identity(fsat, fcon, fbri, fwarm, flift); }
}
