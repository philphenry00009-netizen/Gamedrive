package com.gamelab.spaceplus;

import android.Manifest;
import android.app.Activity;
import android.app.AppOpsManager;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.IntConsumer;
import java.util.function.IntFunction;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {

    private static final int BG = 0xFF0A0A0C, CARD = 0xFF17171C,
            RED = 0xFFFF2D4A, DIM = 0xFF8A8A96, GREEN = 0xFF00E676, AMBER = 0xFFFFB300;
    private static final int REQ_SHIZUKU = 1;

    private static final String[] HINTS_GAME = {
            "Full detail. Heaviest on GPU and battery.",
            "Slightly softer, small saving.",
            "Softer, good saving.",
            "Balanced: soft but smooth. Recommended.",
            "Faster: clearly soft, big saving.",
            "Maximum saving: very soft."};
    private static final String[] HINTS_WHOLE = {
            "Full detail. Heaviest on GPU and battery.",
            "Balanced: sharp enough, much lighter.",
            "Fast: noticeably softer, big GPU saving.",
            "Faster: soft image, very smooth.",
            "Pixel mode: chunky blocks, maximum FPS. Changes the whole phone screen."};


    private static final class App { String pkg, label; Drawable icon; }

    /** A labelled slider that can be updated from code. */
    private final class SeekRow {
        SeekBar sb; TextView val; int min; IntFunction<String> fmt;
        void set(int v) { sb.setProgress(v - min); val.setText(fmt.apply(v)); }
    }

    private SharedPreferences sp;
    private int screen;               // 0 home, 1 game, 2 add game, 3 settings, 4 app list, 5 diagnostics
    private TextView tTemp, tRam, tBatt, tLog;
    private List<App> appCache;
    private Set<String> selSet = new LinkedHashSet<>();
    private String selKey = "protect";

    private final Shizuku.OnBinderReceivedListener onBinder = () -> runOnUiThread(this::softRefresh);
    private final Shizuku.OnBinderDeadListener onDead = () -> runOnUiThread(this::softRefresh);
    private final Shizuku.OnRequestPermissionResultListener onPerm = (c, r) -> runOnUiThread(this::softRefresh);
    private final BroadcastReceiver battReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) { stats(); }
    };

    // ============================================================ lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = Store.sp(this);
        Shizuku.addBinderReceivedListenerSticky(onBinder);
        Shizuku.addBinderDeadListener(onDead);
        Shizuku.addRequestPermissionResultListener(onPerm);
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 0);
        }
        home();
    }

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter f = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(battReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(battReceiver, f);
        recoverIfNeeded();
        if (screen == 0) home();
    }

    @Override
    protected void onPause() {
        try { unregisterReceiver(battReceiver); } catch (Exception ignored) {}
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(onBinder);
        Shizuku.removeBinderDeadListener(onDead);
        Shizuku.removeRequestPermissionResultListener(onPerm);
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (screen == 4 || screen == 5) settings();
        else if (screen != 0) home();
        else super.onBackPressed();
    }

    private void softRefresh() { if (screen == 0) home(); }

    /** A session flagged active with no service running means a crash/reboot: put the phone back. */
    private void recoverIfNeeded() {
        if (sp.getBoolean("active", false) && !GameService.running && ShizukuHelper.granted()) {
            ShizukuHelper.with(s -> {
                Engine.restore(this, s);
                runOnUiThread(() -> { log("Previous session was restored to normal."); softRefresh(); });
            }, e -> {});
        }
    }

    // ============================================================ permissions / state
    private boolean overlayOk() { return Settings.canDrawOverlays(this); }

    private boolean usageOk() {
        AppOpsManager ao = getSystemService(AppOpsManager.class);
        return ao.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), getPackageName())
                == AppOpsManager.MODE_ALLOWED;
    }

    private void setupAction() {
        if (!ShizukuHelper.running()) {
            Intent i = getPackageManager().getLaunchIntentForPackage(Engine.SHIZUKU);
            if (i != null) startActivity(i); else log("Install and start Shizuku first.");
            return;
        }
        if (!ShizukuHelper.granted()) { Shizuku.requestPermission(REQ_SHIZUKU); return; }
        final String me = getPackageName();
        log("Granting permissions…");
        ShizukuHelper.with(s -> {
            s.exec("appops set " + me + " SYSTEM_ALERT_WINDOW allow; "
                 + "appops set " + me + " GET_USAGE_STATS allow; "
                 + "pm grant " + me + " android.permission.POST_NOTIFICATIONS 2>/dev/null; "
                 + "cmd deviceidle whitelist +" + me + " 2>/dev/null");
            runOnUiThread(() -> { log("Permissions granted."); softRefresh(); });
        }, e -> runOnUiThread(() -> log("Error: " + e)));
    }

    private void play(Profile p) {
        if (!ShizukuHelper.granted()) { log("Shizuku isn't ready. Go back and finish setup."); return; }
        if (!usageOk()) { log("Usage access missing. Go back and tap the setup button."); return; }
        if (getPackageManager().getLaunchIntentForPackage(p.pkg) == null) { log("This game isn't installed anymore."); return; }
        if (GameService.running) { log("A session is already running."); return; }
        Store.upsert(this, p);
        startForegroundService(new Intent(this, GameService.class)
                .setAction(GameService.ACTION_PLAY).putExtra(GameService.EXTRA_PKG, p.pkg));
        log("Boosting…");
    }

    private void resetNow() {
        if (GameService.running) {
            startForegroundService(new Intent(this, GameService.class).setAction(GameService.ACTION_END));
            log("Restoring…");
        } else {
            ShizukuHelper.with(s -> {
                Engine.restore(this, s);
                runOnUiThread(() -> { log("Everything restored to normal."); softRefresh(); });
            }, e -> runOnUiThread(() -> log("Error: " + e)));
        }
    }

    private void previewFilter(final Profile p) {
        if (sp.getBoolean("active", false)) { log("End the current session first."); return; }
        if (!p.boostOn()) { log("Colour boost is neutral — move a slider or pick a preset first."); return; }
        if (!ShizukuHelper.granted()) { log("Shizuku isn't ready."); return; }
        ShizukuHelper.with(s -> {
            String out = s.exec(Filter.raw(p.fsat, p.fcon, p.fbri, p.fwarm, p.flift));
            final boolean ok = Filter.succeeded(out);
            runOnUiThread(() -> {
                log(ok ? "Previewing for 5 seconds… (if you see no change, this phone ignores colour boost; use the Screen filter above)" : "This phone rejected colour boost. Use the Screen filter above.");
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> ShizukuHelper.with(s2 -> s2.exec(Filter.off()), e2 -> {}), 5000);
            });
        }, e -> runOnUiThread(() -> log("Error: " + e)));
    }

    // ============================================================ HOME
    private void home() {
        screen = 0;
        LinearLayout root = page();

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        TextView t = tv("GAME SPACE PLUS", 24, Color.WHITE, true);
        t.setLetterSpacing(0.1f);
        titles.addView(t);
        titles.addView(tv("Tune. Play. Auto-reset.", 12, DIM, false));
        head.addView(titles, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button gear = btn("⚙", CARD, Color.WHITE);
        gear.setOnClickListener(v -> settings());
        head.addView(gear, new LinearLayout.LayoutParams(dp(52), dp(48)));
        root.addView(head);

        LinearLayout strip = new LinearLayout(this);
        strip.setBackground(rr(CARD, 14));
        strip.setPadding(dp(8), dp(14), dp(8), dp(14));
        tTemp = stat(strip, "TEMP");
        tRam = stat(strip, "RAM FREE");
        tBatt = stat(strip, "BATTERY");
        root.addView(strip, lp(dp(16)));
        stats();

        boolean run = ShizukuHelper.running(), ok = ShizukuHelper.granted();
        boolean ov = overlayOk(), us = usageOk();
        if (!(ok && ov && us)) {
            LinearLayout card = card(CARD);
            card.addView(tv("SETUP", 11, DIM, true));
            card.addView(tv(dot("Shizuku running", run) + dot("Shizuku permission", ok)
                    + dot("Overlay (in-game dock)", ov) + dot("Usage access (auto-reset)", us),
                    13, Color.WHITE, false), lp(dp(6)));
            Button b = btn(!run ? "Open Shizuku" : !ok ? "Allow Shizuku access" : "Grant overlay + usage access",
                    RED, Color.WHITE);
            b.setOnClickListener(v -> setupAction());
            card.addView(b, lp(dp(10)));
            root.addView(card, lp(dp(12)));
        }

        if (sp.getBoolean("active", false)) {
            LinearLayout card = card(0xFF2A0F16);
            card.addView(tv("SESSION ACTIVE", 11, RED, true));
            card.addView(tv("Boosted. Your normal settings come back automatically when the game closes.",
                    13, Color.WHITE, false), lp(dp(4)));
            Button b = btn("Reset to normal now", AMBER, Color.BLACK);
            b.setOnClickListener(v -> resetNow());
            card.addView(b, lp(dp(10)));
            root.addView(card, lp(dp(12)));
        }

        root.addView(tv("MY GAMES", 11, DIM, true), lp(dp(22)));
        GridLayout grid = new GridLayout(this);
        grid.setColumnCount(3);
        for (final Profile p : Store.games(this)) {
            LinearLayout tile = tile();
            ImageView ic = new ImageView(this);
            try { ic.setImageDrawable(getPackageManager().getApplicationIcon(p.pkg)); } catch (Exception ignored) {}
            tile.addView(ic, new LinearLayout.LayoutParams(dp(56), dp(56)));
            TextView n = tv(p.label, 11, Color.WHITE, false);
            n.setMaxLines(1); n.setEllipsize(TextUtils.TruncateAt.END); n.setGravity(Gravity.CENTER);
            tile.addView(n, lp(dp(6)));
            tile.setOnClickListener(v -> gameScreen(p));
            grid.addView(tile, tileLp());
        }
        LinearLayout add = tile();
        TextView plus = tv("+", 34, RED, true);
        plus.setGravity(Gravity.CENTER);
        add.addView(plus, new LinearLayout.LayoutParams(dp(56), dp(56)));
        add.addView(tv("Add game", 11, DIM, false), lp(dp(6)));
        add.setOnClickListener(v -> picker());
        grid.addView(add, tileLp());
        root.addView(grid, lp(dp(8)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(16)));
        show(root);
    }

    private TextView stat(LinearLayout strip, String label) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        TextView v = tv("—", 18, Color.WHITE, true);
        v.setGravity(Gravity.CENTER);
        col.addView(v);
        TextView l = tv(label, 10, DIM, true);
        l.setGravity(Gravity.CENTER);
        col.addView(l);
        strip.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return v;
    }

    private void stats() {
        if (screen != 0 || tTemp == null) return;
        float t = Sys.tempC(this);
        tTemp.setText(t < 0 ? "—" : String.format(Locale.US, "%.1f°", t));
        tTemp.setTextColor(t >= 42 ? RED : t >= 39 ? AMBER : GREEN);
        long r = Sys.ramFreeMb();
        tRam.setText(r < 0 ? "—" : String.format(Locale.US, "%.1f GB", r / 1024f));
        tBatt.setText(Sys.battPct(this) + "%");
    }

    private static String dot(String label, boolean v) { return (v ? "●  " : "○  ") + label + "\n"; }

    // ============================================================ GAME PROFILE
    private void gameScreen(final Profile p) {
        screen = 1;
        LinearLayout root = page();
        root.addView(back(this::home));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView ic = new ImageView(this);
        try { ic.setImageDrawable(getPackageManager().getApplicationIcon(p.pkg)); } catch (Exception ignored) {}
        head.addView(ic, new LinearLayout.LayoutParams(dp(56), dp(56)));
        TextView name = tv(p.label, 22, Color.WHITE, true);
        name.setPadding(dp(14), 0, 0, 0);
        head.addView(name);
        root.addView(head, lp(dp(10)));

        // ---- resolution
        root.addView(tv("RESOLUTION", 11, DIM, true), lp(dp(20)));
        LinearLayout mrow = new LinearLayout(this);
        final Button mG = btn("Game only (recommended)", CARD, Color.WHITE);
        final Button mW = btn("Whole screen", CARD, Color.WHITE);
        mG.setTextSize(12); mW.setTextSize(12);
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(0, dp(44), 1f);
        ml.rightMargin = dp(6);
        mrow.addView(mG, ml);
        mrow.addView(mW, new LinearLayout.LayoutParams(0, dp(44), 1f));
        root.addView(mrow, lp(dp(6)));
        final LinearLayout resHolder = new LinearLayout(this);
        resHolder.setOrientation(LinearLayout.VERTICAL);
        root.addView(resHolder);
        mG.setOnClickListener(v -> { p.rmode = 0; Store.upsert(this, p); buildRes(p, resHolder, mG, mW); });
        mW.setOnClickListener(v -> { p.rmode = 1; Store.upsert(this, p); buildRes(p, resHolder, mG, mW); });
        buildRes(p, resHolder, mG, mW);
        root.addView(tv("Game only shrinks just the game's picture; the rest of the phone stays sharp and touch "
                + "stays accurate. Whole screen changes the phone's display size (needed for 480p/360p).",
                11, DIM, false), lp(dp(4)));

        // ---- screen filter (overlay: always works)
        root.addView(tv("SCREEN FILTER", 11, DIM, true), lp(dp(20)));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout fr = new LinearLayout(this);
        final Button[] fchips = new Button[Tint.NAMES.length];
        for (int i = 0; i < Tint.NAMES.length; i++) {
            final int idx = i;
            Button b = btn(Tint.NAMES[i], i == p.ftype ? RED : CARD, Color.WHITE);
            b.setTextSize(12);
            b.setOnClickListener(v -> {
                p.ftype = idx; Store.upsert(this, p);
                for (int k = 0; k < fchips.length; k++) fchips[k].setBackground(rr(k == idx ? RED : CARD, 12));
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(104), dp(44));
            l.rightMargin = dp(6);
            fr.addView(b, l);
            fchips[i] = b;
        }
        hs.addView(fr);
        root.addView(hs, lp(dp(6)));
        seek(root, "Filter strength", 5, Tint.MAX_PCT, p.fstr, v -> v + "%", v -> p.fstr = v, p);
        Button prevT = btn("Preview filter (6 s)", CARD, Color.WHITE);
        prevT.setOnClickListener(v -> previewTint(p));
        root.addView(prevT, lp(dp(8)));
        seek(root, "Screen brightness", 0, 255, p.bright, v -> v == 0 ? "unchanged" : String.valueOf(v), v -> p.bright = v, p);

        // ---- colour boost (advanced, SurfaceFlinger)
        root.addView(tv("COLOUR BOOST (advanced — some phones ignore it)", 11, DIM, true), lp(dp(20)));
        final SeekRow[] rows = new SeekRow[5];
        HorizontalScrollView hs2 = new HorizontalScrollView(this);
        hs2.setHorizontalScrollBarEnabled(false);
        LinearLayout fr2 = new LinearLayout(this);
        for (int i = 0; i < Filter.NAMES.length; i++) {
            final int idx = i;
            Button b = btn(Filter.NAMES[i], CARD, Color.WHITE);
            b.setTextSize(12);
            b.setOnClickListener(v -> {
                int[] pv = Filter.PRESETS[idx];
                p.fsat = pv[0]; p.fcon = pv[1]; p.fbri = pv[2]; p.fwarm = pv[3]; p.flift = pv[4];
                for (int k = 0; k < rows.length; k++) rows[k].set(pv[k]);
                Store.upsert(this, p);
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(dp(104), dp(44));
            l.rightMargin = dp(6);
            fr2.addView(b, l);
        }
        hs2.addView(fr2);
        root.addView(hs2, lp(dp(6)));
        rows[0] = seek(root, "Saturation", 50, 180, p.fsat, v -> v + "%", v -> p.fsat = v, p);
        rows[1] = seek(root, "Contrast", 80, 130, p.fcon, v -> v + "%", v -> p.fcon = v, p);
        rows[2] = seek(root, "Brightness boost", 100, 140, p.fbri, v -> v + "%", v -> p.fbri = v, p);
        rows[3] = seek(root, "Warmth", -50, 50, p.fwarm, v -> v == 0 ? "neutral" : (v > 0 ? "warm +" + v : "cool " + v), v -> p.fwarm = v, p);
        rows[4] = seek(root, "Shadow lift", 0, 15, p.flift, v -> v + "%", v -> p.flift = v, p);
        Button prev = btn("Preview colour boost (5 s)", CARD, Color.WHITE);
        prev.setOnClickListener(v -> previewFilter(p));
        root.addView(prev, lp(dp(10)));

        // ---- boost options
        root.addView(tv("BOOST OPTIONS", 11, DIM, true), lp(dp(20)));
        root.addView(flagSwitch("Close all other apps when starting", p, Engine.F_KILLALL));
        root.addView(flagSwitch("Keep them closed (block auto-restart)", p, Engine.F_PERSIST));
        root.addView(flagSwitch("Clear cached background processes", p, Engine.F_KILL));
        root.addView(flagSwitch("Game Mode: performance (experimental)", p, Engine.F_GAME));
        root.addView(flagSwitch("Sustained performance mode (experimental)", p, Engine.F_SUST));
        root.addView(flagSwitch("Do Not Disturb", p, Engine.F_DND));
        root.addView(flagSwitch("Disable window blur", p, Engine.F_BLUR));
        root.addView(flagSwitch("Turn off system animations (experimental)", p, Engine.F_ANIM));
        root.addView(flagSwitch("Disable battery saver & adaptive battery", p, Engine.F_BATT));
        root.addView(flagSwitch("Keep screen on (30 min timeout)", p, Engine.F_SCREEN));

        Button safe = btn("Reset this game to safe defaults", CARD, DIM);
        safe.setOnClickListener(v -> {
            Profile d = new Profile();
            d.pkg = p.pkg; d.label = p.label;
            Store.upsert(this, d);
            gameScreen(d);
        });
        root.addView(safe, lp(dp(14)));

        Button play = btn("PLAY", RED, Color.WHITE);
        play.setTextSize(18);
        play.setTypeface(Typeface.DEFAULT_BOLD);
        play.setOnClickListener(v -> play(p));
        root.addView(play, lp(dp(60), dp(22)));

        Button rm = btn("Remove from Game Space Plus", BG, DIM);
        rm.setOnClickListener(v -> { Store.remove(this, p.pkg); home(); });
        root.addView(rm, lp(dp(8)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(10)));
        show(root);
    }

    private void buildRes(final Profile p, final LinearLayout holder, final Button mG, final Button mW) {
        holder.removeAllViews();
        mG.setBackground(rr(p.rmode == 0 ? RED : CARD, 12));
        mW.setBackground(rr(p.rmode == 1 ? RED : CARD, 12));
        final String[] names = p.rmode == 0 ? Engine.DOWN_NAMES : Engine.RES_NAMES;
        final String[] hints = p.rmode == 0 ? HINTS_GAME : HINTS_WHOLE;
        int sel = p.rmode == 0 ? p.res : p.wres;
        final TextView hint = tv(hints[sel], 12, DIM, false);
        final Button[] chips = new Button[names.length];
        LinearLayout row = new LinearLayout(this);
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            Button b = btn(names[i], i == sel ? RED : CARD, Color.WHITE);
            b.setTextSize(12);
            b.setMinWidth(0); b.setMinimumWidth(0);
            b.setPadding(0, 0, 0, 0);
            b.setOnClickListener(v -> {
                if (p.rmode == 0) p.res = idx; else p.wres = idx;
                Store.upsert(this, p);
                for (int k = 0; k < chips.length; k++) chips[k].setBackground(rr(k == idx ? RED : CARD, 10));
                hint.setText(hints[idx]);
            });
            LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(0, dp(44), 1f);
            l.rightMargin = dp(4);
            row.addView(b, l);
            chips[i] = b;
        }
        holder.addView(row, lp(dp(8)));
        holder.addView(hint, lp(dp(6)));
        if (p.rmode == 1) holder.addView(flagSwitch("Scale density with resolution (keeps UI size)", p, 0), lp(dp(6)));
    }

    private void previewTint(final Profile p) {
        if (!overlayOk()) { log("Overlay permission is missing. Go back and tap the setup button."); return; }
        if (p.ftype == 0) { log("Filter is Off. Pick a filter first."); return; }
        final Tint t = new Tint(this);
        t.set(p.ftype, p.fstr);
        t.show();
        log("Previewing for 6 seconds…");
        new Handler(Looper.getMainLooper()).postDelayed(t::hide, 6000);
    }

    /** flag == 0 means the "scale density" boolean. */
    private Switch flagSwitch(String label, final Profile p, final int flag) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setTextSize(14);
        s.setPadding(0, dp(9), 0, dp(9));
        s.setChecked(flag == 0 ? p.dens : (p.flags & flag) != 0);
        s.setOnCheckedChangeListener((b, on) -> {
            if (flag == 0) p.dens = on;
            else p.flags = on ? (p.flags | flag) : (p.flags & ~flag);
            Store.upsert(this, p);
        });
        return s;
    }

    private SeekRow seek(LinearLayout root, String label, final int min, int max, int value,
                         IntFunction<String> fmt, final IntConsumer setter, final Profile p) {
        final SeekRow r = new SeekRow();
        r.min = min;
        r.fmt = fmt;

        LinearLayout head = new LinearLayout(this);
        TextView l = tv(label, 13, Color.WHITE, false);
        head.addView(l, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        r.val = tv(fmt.apply(value), 13, RED, true);
        head.addView(r.val);
        root.addView(head, lp(dp(12)));

        r.sb = new SeekBar(this);
        r.sb.setMax(max - min);
        r.sb.setProgress(value - min);
        r.sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int prog, boolean fromUser) {
                r.val.setText(r.fmt.apply(min + prog));
                if (fromUser) setter.accept(min + prog);
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) { Store.upsert(MainActivity.this, p); }
        });
        root.addView(r.sb, lp(dp(2)));
        return r;
    }

    // ============================================================ ADD GAME
    private void picker() {
        screen = 2;
        LinearLayout root = page();
        root.addView(back(this::home));
        root.addView(tv("Add a game", 22, Color.WHITE, true), lp(dp(10)));
        final EditText search = searchBox();
        root.addView(search, lp(dp(12)));
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, lp(dp(8)));
        list.addView(tv("Loading…", 13, DIM, false));
        show(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { fillGames(list, e.toString()); }
        });
        new Thread(() -> {
            List<App> apps = loadApps(true);
            runOnUiThread(() -> { appCache = apps; fillGames(list, search.getText().toString()); });
        }).start();
    }

    private List<App> loadApps(boolean excludeGames) {
        PackageManager pm = getPackageManager();
        Set<String> have = new HashSet<>();
        if (excludeGames) for (Profile p : Store.games(this)) have.add(p.pkg);
        List<App> out = new ArrayList<>();
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(getPackageName()) || have.contains(pkg)) continue;
            App a = new App();
            a.pkg = pkg;
            a.label = String.valueOf(ri.loadLabel(pm));
            a.icon = ri.loadIcon(pm);
            out.add(a);
        }
        Collections.sort(out, (x, y) -> x.label.compareToIgnoreCase(y.label));
        return out;
    }

    private void fillGames(LinearLayout list, String q) {
        list.removeAllViews();
        if (appCache == null) return;
        String f = q.toLowerCase(Locale.ROOT).trim();
        for (final App a : appCache) {
            if (!f.isEmpty() && !a.label.toLowerCase(Locale.ROOT).contains(f)) continue;
            LinearLayout r = appRow(a);
            r.setOnClickListener(v -> {
                Profile p = new Profile();
                p.pkg = a.pkg;
                p.label = a.label;
                Store.upsert(this, p);
                gameScreen(p);
            });
            list.addView(r);
        }
    }

    private LinearLayout appRow(App a) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(4), dp(10), dp(4), dp(10));
        ImageView ic = new ImageView(this);
        ic.setImageDrawable(a.icon);
        r.addView(ic, new LinearLayout.LayoutParams(dp(40), dp(40)));
        TextView n = tv(a.label, 15, Color.WHITE, false);
        n.setPadding(dp(14), 0, 0, 0);
        r.addView(n, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return r;
    }

    private EditText searchBox() {
        EditText search = new EditText(this);
        search.setHint("Search apps");
        search.setHintTextColor(DIM);
        search.setTextColor(Color.WHITE);
        search.setBackground(rr(CARD, 12));
        search.setPadding(dp(14), dp(12), dp(14), dp(12));
        search.setSingleLine(true);
        return search;
    }

    // ============================================================ APP LIST (protected / always-close)
    private void listPicker(final String key, String title, String sub) {
        screen = 4;
        selKey = key;
        selSet = Store.getSet(this, key);
        LinearLayout root = page();
        root.addView(back(this::settings));
        root.addView(tv(title, 22, Color.WHITE, true), lp(dp(10)));
        root.addView(tv(sub, 12, DIM, false), lp(dp(4)));
        final EditText search = searchBox();
        root.addView(search, lp(dp(12)));
        final LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        root.addView(list, lp(dp(8)));
        list.addView(tv("Loading…", 13, DIM, false));
        show(root);

        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable e) { fillList(list, e.toString()); }
        });
        new Thread(() -> {
            List<App> apps = loadApps(false);
            runOnUiThread(() -> { appCache = apps; fillList(list, search.getText().toString()); });
        }).start();
    }

    private void fillList(LinearLayout list, String q) {
        list.removeAllViews();
        if (appCache == null) return;
        String f = q.toLowerCase(Locale.ROOT).trim();
        for (int pass = 0; pass < 2; pass++) {          // selected apps first
            for (final App a : appCache) {
                boolean sel = selSet.contains(a.pkg);
                if ((pass == 0) != sel) continue;
                if (!f.isEmpty() && !a.label.toLowerCase(Locale.ROOT).contains(f)) continue;
                LinearLayout r = appRow(a);
                final Switch sw = new Switch(this);
                sw.setChecked(sel);
                sw.setOnCheckedChangeListener((b, on) -> {
                    if (on) selSet.add(a.pkg); else selSet.remove(a.pkg);
                    Store.putSet(this, selKey, selSet);
                });
                r.addView(sw);
                r.setOnClickListener(v -> sw.toggle());
                list.addView(r);
            }
        }
    }

    // ============================================================ SETTINGS
    private void settings() {
        screen = 3;
        LinearLayout root = page();
        root.addView(back(this::home));
        root.addView(tv("Settings", 22, Color.WHITE, true), lp(dp(10)));

        root.addView(tv("BACKGROUND APPS", 11, DIM, true), lp(dp(18)));
        Button prot = btn("Protected apps — never closed (" + Store.getSet(this, "protect").size() + ")", CARD, Color.WHITE);
        prot.setOnClickListener(v -> listPicker("protect", "Protected apps",
                "These keep running in the background while you play."));
        root.addView(prot, lp(dp(8)));
        Button close = btn("Always-close apps (" + Store.getSet(this, "close").size() + ")", CARD, Color.WHITE);
        close.setOnClickListener(v -> listPicker("close", "Always-close apps",
                "Closed every time, even pre-installed apps that Android keeps restarting."));
        root.addView(close, lp(dp(8)));
        root.addView(tv("Always kept running: the game, this app, Shizuku, your keyboard and your launcher.",
                12, DIM, false), lp(dp(6)));

        root.addView(tv("SESSION", 11, DIM, true), lp(dp(20)));
        root.addView(prefSwitch("In-game dock (turn on once you confirm taps work)", "overlay", false), lp(dp(4)));
        root.addView(prefSwitch("Thermal guard: lower resolution when hot", "thermal", true));
        root.addView(stepper("Thermal limit (°C)", "tlimit", 42, 36, 50, 1));
        root.addView(stepper("Auto-reset delay after leaving game (sec)", "grace", 8, 4, 30, 2));

        root.addView(tv("TOOLS", 11, DIM, true), lp(dp(20)));
        Button diag = btn("Run diagnostics", CARD, Color.WHITE);
        diag.setOnClickListener(v -> diagScreen());
        root.addView(diag, lp(dp(8)));
        Button reset = btn("Reset phone to normal now", AMBER, Color.BLACK);
        reset.setOnClickListener(v -> resetNow());
        root.addView(reset, lp(dp(8)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(10)));
        show(root);
    }

    private Switch prefSwitch(String label, final String key, boolean def) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setTextColor(Color.WHITE);
        s.setTextSize(14);
        s.setPadding(0, dp(9), 0, dp(9));
        s.setChecked(sp.getBoolean(key, def));
        s.setOnCheckedChangeListener((b, on) -> sp.edit().putBoolean(key, on).apply());
        return s;
    }

    private LinearLayout stepper(String label, final String key, final int def, final int min, final int max, final int step) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(6), 0, dp(6));
        row.addView(tv(label, 14, Color.WHITE, false), new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        final TextView val = tv(String.valueOf(sp.getInt(key, def)), 16, Color.WHITE, true);
        val.setGravity(Gravity.CENTER);
        Button minus = btn("−", CARD, Color.WHITE);
        Button plus = btn("+", CARD, Color.WHITE);
        minus.setOnClickListener(v -> {
            int n = Math.max(min, sp.getInt(key, def) - step);
            sp.edit().putInt(key, n).apply(); val.setText(String.valueOf(n));
        });
        plus.setOnClickListener(v -> {
            int n = Math.min(max, sp.getInt(key, def) + step);
            sp.edit().putInt(key, n).apply(); val.setText(String.valueOf(n));
        });
        row.addView(minus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        row.addView(val, new LinearLayout.LayoutParams(dp(48), LinearLayout.LayoutParams.WRAP_CONTENT));
        row.addView(plus, new LinearLayout.LayoutParams(dp(44), dp(44)));
        return row;
    }

    // ============================================================ DIAGNOSTICS
    private void diagScreen() {
        screen = 5;
        LinearLayout root = page();
        root.addView(back(this::settings));
        root.addView(tv("Diagnostics", 22, Color.WHITE, true), lp(dp(10)));
        root.addView(tv("Checks what this phone accepts. Copy the report if you need help.", 12, DIM, false), lp(dp(4)));

        final TextView out = tv("", 12, Color.WHITE, false);
        out.setTypeface(Typeface.MONOSPACE);
        out.setBackground(rr(CARD, 12));
        out.setPadding(dp(14), dp(12), dp(14), dp(12));
        out.setTextIsSelectable(true);

        Button run = btn("Run again", RED, Color.WHITE);
        run.setOnClickListener(v -> runDiag(out));
        root.addView(run, lp(dp(12)));
        root.addView(out, lp(dp(10)));

        Button copy = btn("Copy report", CARD, Color.WHITE);
        copy.setOnClickListener(v -> {
            ClipboardManager cm = getSystemService(ClipboardManager.class);
            cm.setPrimaryClip(ClipData.newPlainText("Game Space Plus report", out.getText()));
            log("Report copied.");
        });
        root.addView(copy, lp(dp(10)));

        tLog = tv("", 12, DIM, false);
        root.addView(tLog, lp(dp(8)));
        show(root);
        runDiag(out);
    }

    private void runDiag(final TextView out) {
        if (!ShizukuHelper.granted()) { out.setText("Shizuku isn't running or permission isn't granted yet."); return; }
        out.setText("Running checks…");
        ShizukuHelper.with(s -> {
            String r = Diag.run(this, s);
            runOnUiThread(() -> out.setText(r));
        }, e -> runOnUiThread(() -> out.setText("Error: " + e)));
    }

    // ============================================================ UI helpers
    private void log(String s) { if (tLog != null) tLog.setText(s); }

    private LinearLayout page() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(36), dp(20), dp(28));
        return root;
    }

    private void show(LinearLayout root) {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(BG);
        sv.setFitsSystemWindows(true);
        sv.addView(root);
        setContentView(sv);
    }

    private Button back(final Runnable target) {
        Button b = btn("‹  Back", BG, DIM);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setPadding(0, 0, 0, 0);
        b.setOnClickListener(v -> target.run());
        return b;
    }

    private LinearLayout card(int color) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rr(color, 14));
        c.setPadding(dp(16), dp(14), dp(16), dp(14));
        return c;
    }

    private LinearLayout tile() {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setGravity(Gravity.CENTER_HORIZONTAL);
        t.setBackground(rr(CARD, 14));
        t.setPadding(dp(6), dp(14), dp(6), dp(12));
        return t;
    }

    private GridLayout.LayoutParams tileLp() {
        GridLayout.LayoutParams l = new GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED, 1f), GridLayout.spec(GridLayout.UNDEFINED, 1f));
        l.width = 0;
        l.setMargins(dp(4), dp(4), dp(4), dp(4));
        return l;
    }

    private TextView tv(String s, int sz, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sz); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private Button btn(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s); b.setAllCaps(false); b.setTextColor(fg);
        b.setBackground(rr(bg, 12));
        return b;
    }

    private GradientDrawable rr(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private LinearLayout.LayoutParams lp(int top) {
        return lp(LinearLayout.LayoutParams.WRAP_CONTENT, top);
    }

    private LinearLayout.LayoutParams lp(int h, int top) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, h);
        l.topMargin = top;
        return l;
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
