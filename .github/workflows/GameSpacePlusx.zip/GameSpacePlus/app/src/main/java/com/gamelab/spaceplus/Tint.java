package com.gamelab.spaceplus;

import android.content.Context;
import android.graphics.PixelFormat;
import android.view.View;
import android.view.WindowManager;

/**
 * Full-screen colour layer drawn over the game. It always works (no hidden system calls).
 * Touches pass straight through: the window is not touchable and its opacity is kept at or
 * below 60 %, because Android 12 blocks touches that pass through overlays more opaque than 80 %.
 */
final class Tint {

    static final String[] NAMES = {"Off", "Dim", "Warm", "Cool", "Night", "Brighten", "Shadow lift"};
    private static final int[] COLORS = {
            0, 0xFF000000, 0xFFFF8A2A, 0xFF3C78FF, 0xFFFF5A00, 0xFFFFFFFF, 0xFF8C8C96};
    static final int MAX_PCT = 60;

    private final WindowManager wm;
    private final View view;
    private final WindowManager.LayoutParams lp;
    private boolean attached, wanted;
    private int type, pct = 25;

    Tint(Context c) {
        wm = c.getApplicationContext().getSystemService(WindowManager.class);
        view = new View(c.getApplicationContext());
        lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
    }

    /** Choose the filter. Takes effect immediately if the layer is currently showing. */
    void set(int type, int strengthPct) {
        this.type = type;
        this.pct = Math.max(3, Math.min(MAX_PCT, strengthPct));
        if (type == 0) { hide(); return; }
        view.setBackgroundColor(COLORS[type]);
        lp.alpha = pct / 100f;
        if (attached) {
            try { wm.updateViewLayout(view, lp); } catch (Exception ignored) {}
        } else if (wanted) {
            show();
        }
    }

    void show() {
        wanted = true;
        if (attached || type == 0) return;
        try {
            view.setBackgroundColor(COLORS[type]);
            lp.alpha = pct / 100f;
            wm.addView(view, lp);
            attached = true;
        } catch (Exception ignored) {}
    }

    void hide() {
        wanted = false;
        if (!attached) return;
        try { wm.removeView(view); } catch (Exception ignored) {}
        attached = false;
    }
}
