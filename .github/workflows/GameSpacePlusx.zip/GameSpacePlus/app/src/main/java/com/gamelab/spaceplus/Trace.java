package com.gamelab.spaceplus;

import android.content.Context;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Small rolling event log, shown in Diagnostics, so a problem can be traced after the fact. */
final class Trace {
    private static final int MAX_LINES = 60;

    static synchronized void add(Context c, String msg) {
        String line = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date()) + "  " + msg;
        String[] old = Store.sp(c).getString("trace", "").split("\n");
        StringBuilder sb = new StringBuilder();
        int start = Math.max(0, old.length - (MAX_LINES - 1));
        for (int i = start; i < old.length; i++) if (!old[i].isEmpty()) sb.append(old[i]).append('\n');
        sb.append(line).append('\n');
        Store.sp(c).edit().putString("trace", sb.toString()).apply();
    }

    static String get(Context c) {
        String t = Store.sp(c).getString("trace", "");
        return t.isEmpty() ? "(nothing yet)\n" : t;
    }

    static void clear(Context c) { Store.sp(c).edit().putString("trace", "").apply(); }
}
