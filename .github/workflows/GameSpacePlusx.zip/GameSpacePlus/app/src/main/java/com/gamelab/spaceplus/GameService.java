package com.gamelab.spaceplus;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.widget.Toast;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Owns one gaming session: applies the profile, watches which app is in front,
 * keeps background apps closed, shows the screen filter and (optionally) the dock,
 * and restores everything automatically when the game is no longer in front.
 */
public class GameService extends Service {

    static final String ACTION_PLAY = "com.gamelab.spaceplus.PLAY";
    static final String ACTION_END = "com.gamelab.spaceplus.END";
    static final String EXTRA_PKG = "pkg";
    static volatile boolean running;

    private static final String CH = "session";
    private static final int NOTIF_ID = 1;
    private static final long POLL_MS = 2000, START_TIMEOUT_MS = 40000,
            GUARD_COOLDOWN_MS = 90000, SWEEP_MS = 20000;

    /** Screens that appear over a game without meaning the player left it. */
    private static final Set<String> NEUTRAL = new HashSet<>(Arrays.asList(
            "android", "com.android.systemui", "com.samsung.android.game.gametools",
            "com.samsung.android.game.gos", "com.samsung.android.app.cocktailbarservice",
            "com.google.android.permissioncontroller", "com.android.permissioncontroller"));

    private final Handler h = new Handler(Looper.getMainLooper());
    private UsageStatsManager usm;
    private Profile prof;
    private Overlay dock;
    private Tint tint;
    private boolean seen, ending, dockDnd;
    private volatile boolean sweeping;
    private long startT, awayT, lastGuard, lastNotif, lastQuery, lastSweep;
    private String fg = "";

    @Override
    public void onCreate() {
        super.onCreate();
        running = true;
        usm = getSystemService(UsageStatsManager.class);
        getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel(CH, "Game session", NotificationManager.IMPORTANCE_LOW));
    }

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        hideLayers();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String act = intent == null ? null : intent.getAction();
        startForeground(NOTIF_ID, notif(prof == null ? "Preparing…" : "Game Space Plus"));

        if (ACTION_END.equals(act)) {
            if (prof == null) { endNoProfile(); } else { endSession("Reset"); }
            return START_NOT_STICKY;
        }
        if (ACTION_PLAY.equals(act) && prof == null) {
            final Profile p = Store.find(this, intent.getStringExtra(EXTRA_PKG));
            if (p == null) { stopSelf(); return START_NOT_STICKY; }
            prof = p;
            seen = false;
            ending = false;
            startForeground(NOTIF_ID, notif("Boosting for " + p.label + "…"));
            ShizukuHelper.with(s -> {
                String msg = Engine.apply(this, s, p);
                h.post(() -> { toast(msg); beginMonitoring(); });
            }, e -> h.post(() -> {
                Trace.add(this, "apply failed: " + e);
                toast("Boost failed: " + e);
                prof = null;
                stopForeground(true);
                stopSelf();
            }));
        } else if (prof == null) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    // ------------------------------------------------------------ monitoring
    private void beginMonitoring() {
        startT = SystemClock.elapsedRealtime();
        lastSweep = startT;
        lastQuery = System.currentTimeMillis() - 5000;
        final boolean canOverlay = Settings.canDrawOverlays(this);

        if (canOverlay && prof.ftype != 0) {
            tint = new Tint(this);
            tint.set(prof.ftype, prof.fstr);
        }
        if (canOverlay && Store.sp(this).getBoolean("overlay", false)) {
            dockDnd = (prof.flags & Engine.F_DND) != 0;
            final boolean whole = prof.rmode == 1;
            dock = new Overlay(this, new Overlay.Actions() {
                @Override public void res(int idx) {
                    ShizukuHelper.with(s -> Engine.setWidth(GameService.this, s, idx, prof.dens), e -> {});
                }
                @Override public void filter(int type) {
                    if (tint == null) tint = new Tint(GameService.this);
                    tint.set(type, prof.fstr);
                    if (type != 0) tint.show();
                }
                @Override public void bright(int delta) {
                    int curB = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128);
                    final int next = Math.max(5, Math.min(255, curB + delta));
                    ShizukuHelper.with(s -> {
                        Engine.setBrightness(GameService.this, s, next);
                        h.post(() -> toast("Brightness " + next + "/255"));
                    }, e -> {});
                }
                @Override public void clearRam() {
                    final String game = prof.pkg;
                    final boolean persist = (prof.flags & Engine.F_PERSIST) != 0;
                    ShizukuHelper.with(s -> {
                        int n = Engine.closeApps(GameService.this, s, game, persist, false);
                        h.post(() -> toast("Closed " + n + " apps"));
                    }, e -> {});
                }
                @Override public void dnd() {
                    dockDnd = !dockDnd;
                    final boolean now = dockDnd;
                    ShizukuHelper.with(s -> Engine.setDnd(GameService.this, s, now), e -> {});
                }
                @Override public void end() { h.post(() -> endSession("Reset")); }
            }, dockDnd, prof.ftype, whole);
            dock.setCurrent(Store.sp(this).getInt("curres", prof.wres));
        }
        Trace.add(this, "monitoring " + prof.pkg + "  filter=" + Tint.NAMES[prof.ftype] + "  dock=" + (dock != null));
        startForeground(NOTIF_ID, notif("Waiting for " + prof.label));
        h.postDelayed(poll, 1500);
    }

    private final Runnable poll = new Runnable() {
        @Override public void run() {
            if (ending || prof == null) return;
            long now = SystemClock.elapsedRealtime();
            readForeground();
            boolean inGame = prof.pkg.equals(fg);
            boolean neutral = NEUTRAL.contains(fg);

            if (inGame) {
                if (!seen) Trace.add(GameService.this, "game is in front");
                seen = true;
                awayT = 0;
                if (tint != null) tint.show();
                if (dock != null) {
                    dock.show();
                    dock.setStats(String.format(Locale.US, "%.1f°C   RAM free %d MB   Batt %d%%",
                            Sys.tempC(GameService.this), Sys.ramFreeMb(), Sys.battPct(GameService.this)));
                }
                thermalGuard(now);
                sweep(now);
            } else {
                hideLayers();
                if (neutral && seen) {
                    awayT = 0;            // a system panel is over the game; keep the session
                } else if (!seen) {
                    if (now - startT > START_TIMEOUT_MS) { endSession("Game didn't start"); return; }
                } else {
                    if (awayT == 0) awayT = now;
                    long grace = Store.sp(GameService.this).getInt("grace", 8) * 1000L;
                    if (now - awayT > grace) { endSession("Game closed"); return; }
                }
            }

            if (now - lastNotif > 10000) {
                lastNotif = now;
                getSystemService(NotificationManager.class).notify(NOTIF_ID, notif(
                        String.format(Locale.US, "%s · %.1f°C", prof.label, Sys.tempC(GameService.this))));
            }
            h.postDelayed(this, POLL_MS);
        }
    };

    private void hideLayers() {
        if (tint != null) tint.hide();
        if (dock != null) dock.hide();
    }

    private void readForeground() {
        long now = System.currentTimeMillis();
        String before = fg;
        try {
            UsageEvents ev = usm.queryEvents(lastQuery, now);
            UsageEvents.Event e = new UsageEvents.Event();
            while (ev.hasNextEvent()) {
                ev.getNextEvent(e);
                if (e.getEventType() == UsageEvents.Event.ACTIVITY_RESUMED) fg = e.getPackageName();
            }
        } catch (SecurityException ignored) {}
        lastQuery = now - 500;
        if (!fg.equals(before)) Trace.add(this, "front app: " + fg);
    }

    /** Android restarts some apps on its own; every 20 s close whatever came back. */
    private void sweep(long now) {
        if (sweeping || now - lastSweep < SWEEP_MS) return;
        boolean on = (prof.flags & Engine.F_KILLALL) != 0 && (prof.flags & Engine.F_PERSIST) != 0;
        if (!on) return;
        sweeping = true;
        lastSweep = now;
        final String game = prof.pkg;
        ShizukuHelper.with(s -> {
            try { Engine.closeApps(GameService.this, s, game, true, false); }
            finally { sweeping = false; }
        }, e -> { sweeping = false; });
    }

    private void thermalGuard(long now) {
        if (!Store.sp(this).getBoolean("thermal", true)) return;
        if (now - lastGuard < GUARD_COOLDOWN_MS) return;
        int limit = Store.sp(this).getInt("tlimit", 42);
        if (Sys.tempC(this) < limit) return;
        lastGuard = now;
        if (prof.rmode != 1) {          // game-only downscale can't change while the game runs
            toast("Phone is hot (" + Math.round(Sys.tempC(this)) + "°C) — consider a break or lower downscale");
            return;
        }
        int cur = Store.sp(this).getInt("curres", prof.wres);
        if (cur >= Engine.WIDTHS.length - 1) return;
        final int next = cur + 1;
        ShizukuHelper.with(s -> {
            Engine.setWidth(this, s, next, prof.dens);
            h.post(() -> {
                toast("Thermal guard: " + Engine.RES_NAMES[next]);
                if (dock != null) dock.setCurrent(next);
            });
        }, e -> {});
    }

    // ------------------------------------------------------------ ending
    private void endSession(final String reason) {
        if (ending) return;
        ending = true;
        h.removeCallbacks(poll);
        hideLayers();
        Trace.add(this, "ending: " + reason + " (front app was " + fg + ")");
        startForeground(NOTIF_ID, notif("Restoring your settings…"));
        ShizukuHelper.with(s -> {
            Engine.restore(this, s);
            h.post(() -> { toast(reason + " — settings restored"); finishService(); });
        }, e -> h.post(() -> {
            toast("Couldn't restore (open Game Space Plus to retry): " + e);
            finishService();
        }));
    }

    /** Reset requested while no session object exists (e.g. notification after a crash). */
    private void endNoProfile() {
        ending = true;
        ShizukuHelper.with(s -> {
            Engine.restore(this, s);
            h.post(() -> { toast("Settings restored"); finishService(); });
        }, e -> h.post(this::finishService));
    }

    private void finishService() {
        prof = null;
        stopForeground(true);
        stopSelf();
    }

    private Notification notif(String text) {
        int fl = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent open = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), fl);
        PendingIntent end = PendingIntent.getForegroundService(this, 1,
                new Intent(this, GameService.class).setAction(ACTION_END), fl);
        return new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Game Space Plus")
                .setContentText(text)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(0, "Reset now", end).build())
                .setOngoing(true)
                .build();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
