package com.gamelab.spaceplus;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class Store {

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences("gsx", Context.MODE_PRIVATE);
    }

    static Set<String> getSet(Context c, String key) {
        Set<String> out = new LinkedHashSet<>();
        for (String x : sp(c).getString(key, "").split("\\s+")) if (!x.isEmpty()) out.add(x);
        return out;
    }

    static void putSet(Context c, String key, Set<String> v) {
        sp(c).edit().putString(key, String.join("\n", v)).apply();
    }

    static List<Profile> games(Context c) {
        List<Profile> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(sp(c).getString("games", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Profile p = new Profile();
                p.pkg = o.getString("pkg");
                p.label = o.optString("label", p.pkg);
                p.rmode = o.optInt("rmode", 0);
                p.res = o.optInt("res", 3);
                p.wres = o.optInt("wres", 1);
                p.dens = o.optBoolean("dens", true);
                p.flags = o.optInt("flags", Engine.DEFAULT_FLAGS);
                p.bright = o.optInt("bright", 0);
                p.ftype = o.optInt("ftype", 0);
                p.fstr = o.optInt("fstr", 25);
                p.fsat = o.optInt("fsat", 100);
                p.fcon = o.optInt("fcon", 100);
                p.fbri = o.optInt("fbri", 100);
                p.fwarm = o.optInt("fwarm", 0);
                p.flift = o.optInt("flift", 0);
                if (p.res < 0 || p.res >= Engine.DOWN_NAMES.length) p.res = 3;
                if (p.wres < 0 || p.wres >= Engine.WIDTHS.length) p.wres = 1;
                if (p.ftype < 0 || p.ftype >= Tint.NAMES.length) p.ftype = 0;
                out.add(p);
            }
        } catch (JSONException ignored) {}
        return out;
    }

    private static void saveAll(Context c, List<Profile> list) {
        JSONArray a = new JSONArray();
        for (Profile p : list) {
            try {
                JSONObject o = new JSONObject();
                o.put("pkg", p.pkg);
                o.put("label", p.label);
                o.put("rmode", p.rmode);
                o.put("res", p.res);
                o.put("wres", p.wres);
                o.put("dens", p.dens);
                o.put("flags", p.flags);
                o.put("bright", p.bright);
                o.put("ftype", p.ftype);
                o.put("fstr", p.fstr);
                o.put("fsat", p.fsat);
                o.put("fcon", p.fcon);
                o.put("fbri", p.fbri);
                o.put("fwarm", p.fwarm);
                o.put("flift", p.flift);
                a.put(o);
            } catch (JSONException ignored) {}
        }
        sp(c).edit().putString("games", a.toString()).apply();
    }

    static Profile find(Context c, String pkg) {
        for (Profile p : games(c)) if (p.pkg.equals(pkg)) return p;
        return null;
    }

    static void upsert(Context c, Profile np) {
        List<Profile> l = games(c);
        boolean found = false;
        for (int i = 0; i < l.size(); i++) {
            if (l.get(i).pkg.equals(np.pkg)) { l.set(i, np); found = true; break; }
        }
        if (!found) l.add(np);
        saveAll(c, l);
    }

    static void remove(Context c, String pkg) {
        List<Profile> l = games(c);
        for (int i = 0; i < l.size(); i++) if (l.get(i).pkg.equals(pkg)) { l.remove(i); break; }
        saveAll(c, l);
    }
}
