package com.gamelab.spaceplus;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;

import rikka.shizuku.Shizuku;

final class ShizukuHelper {

    interface Task { void run(IShellService s) throws Exception; }

    private static final class Pending {
        final Task task; final Consumer<String> err;
        Pending(Task t, Consumer<String> e) { task = t; err = e; }
    }

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final List<Pending> QUEUE = new ArrayList<>();
    private static volatile IShellService svc;
    private static boolean binding;

    private static final Shizuku.UserServiceArgs ARGS = new Shizuku.UserServiceArgs(
            new ComponentName("com.gamelab.spaceplus", ShellService.class.getName()))
            .daemon(false).processNameSuffix("shell").version(1);

    private static final ServiceConnection CONN = new ServiceConnection() {
        @Override public void onServiceConnected(ComponentName n, IBinder b) {
            IShellService s = IShellService.Stub.asInterface(b);
            svc = s;
            List<Pending> copy;
            synchronized (ShizukuHelper.class) {
                binding = false;
                copy = new ArrayList<>(QUEUE);
                QUEUE.clear();
            }
            for (Pending p : copy) dispatch(s, p.task, p.err);
        }
        @Override public void onServiceDisconnected(ComponentName n) {
            svc = null;
            synchronized (ShizukuHelper.class) { binding = false; }
        }
    };

    static boolean running() { return Shizuku.pingBinder(); }
    static boolean granted() { return running() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED; }
    static int serverUid() {
        try { return running() ? Shizuku.getUid() : -1; } catch (Throwable t) { return -1; }
    }

    /** Runs the task on one background thread, binding the shell service first if needed. */
    static synchronized void with(Task task, Consumer<String> err) {
        if (!granted()) { err.accept("Shizuku not running or permission not granted"); return; }
        IShellService s = svc;
        if (s != null && s.asBinder().pingBinder()) { dispatch(s, task, err); return; }
        QUEUE.add(new Pending(task, err));
        if (!binding) {
            binding = true;
            try { Shizuku.bindUserService(ARGS, CONN); }
            catch (Throwable t) { binding = false; QUEUE.clear(); err.accept("Bind failed: " + t); }
        }
    }

    private static void dispatch(IShellService s, Task t, Consumer<String> err) {
        IO.execute(() -> {
            try { t.run(s); } catch (Throwable e) { err.accept(String.valueOf(e)); }
        });
    }
}
