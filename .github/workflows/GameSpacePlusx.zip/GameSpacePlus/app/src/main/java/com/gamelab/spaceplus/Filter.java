package com.gamelab.spaceplus;

import java.util.Locale;

/**
 * Whole-screen colour filter through SurfaceFlinger's colour-matrix call (runs as shell via Shizuku).
 * It sits above the game, costs no GPU, and is wiped by a reboot. Some phones ignore it:
 * the Diagnostics screen tells you whether yours accepts it.
 */
final class Filter {

    static final String[] NAMES = {"Off", "Vivid", "Bright", "Shadow boost", "Warm", "Cool", "Night"};
    /** {saturation %, contrast %, brightness boost %, warmth (-50..50), shadow lift %} */
    static final int[][] PRESETS = {
            {100, 100, 100, 0, 0},
            {140, 110, 100, 0, 0},
            {110, 105, 125, 0, 0},
            {105, 110, 105, 0, 8},
            {100, 100, 95, 25, 0},
            {100, 100, 100, -25, 0},
            {90, 95, 80, 35, 0}};

    static boolean identity(int sat, int con, int bri, int warm, int lift) {
        return sat == 100 && con == 100 && bri == 100 && warm == 0 && lift == 0;
    }

    static String off() { return "service call SurfaceFlinger 1015 i32 0 >/dev/null 2>&1; "; }

    static String on(int sat, int con, int bri, int warm, int lift) {
        return raw(sat, con, bri, warm, lift) + " >/dev/null 2>&1; ";
    }

    /** The bare command (output not discarded), used for the success check. */
    static String raw(int sat, int con, int bri, int warm, int lift) {
        float s = sat / 100f, c = con / 100f, b = bri / 100f, l = lift / 100f;
        final float lr = 0.2126f, lg = 0.7152f, lb = 0.0722f;
        float[][] sm = {
                {(1 - s) * lr + s, (1 - s) * lg, (1 - s) * lb},
                {(1 - s) * lr, (1 - s) * lg + s, (1 - s) * lb},
                {(1 - s) * lr, (1 - s) * lg, (1 - s) * lb + s}};
        float[] gain = {
                c * b * (1 + 0.004f * warm),
                c * b * (1 - 0.001f * warm),
                c * b * (1 - 0.008f * warm)};
        float off = 0.5f * (1 - c) + l;

        float[] m = new float[16];                 // column-major
        for (int col = 0; col < 3; col++)
            for (int row = 0; row < 3; row++) m[col * 4 + row] = gain[row] * sm[row][col];
        m[12] = off; m[13] = off; m[14] = off; m[15] = 1f;

        StringBuilder sb = new StringBuilder("service call SurfaceFlinger 1015 i32 1");
        for (float v : m) sb.append(" f ").append(String.format(Locale.US, "%.4f", v));
        return sb.toString();
    }

    static boolean succeeded(String out) { return out != null && out.contains("Parcel(00000000"); }
}
